const escape = value => String(value ?? '').replace(/[&<>"']/g, character => ({
  '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;',
})[character]);
const number = value => Number(value || 0).toLocaleString('zh-TW');

export function renderPage(title, body, plain = false) {
  return `<!doctype html><html lang="zh-Hant"><meta charset="utf-8">
<meta name="viewport" content="width=device-width,initial-scale=1"><title>${escape(title)}</title>
<style>
:root{color-scheme:light;font:16px/1.55 'Inter','Microsoft JhengHei',sans-serif;color:#142724;background:#eef3ef}
*{box-sizing:border-box}body{margin:0}header{background:#152d27;color:#f7fbf5;padding:32px max(5vw,20px)}
h1,h2,h3,p{margin:0}h1{font-size:clamp(1.6rem,4vw,2.6rem);letter-spacing:-.035em}h2{font-size:1.12rem}
main{max-width:1240px;margin:auto;padding:24px max(3vw,16px) 52px}.layout{display:grid;grid-template-columns:minmax(0,1.25fr) minmax(0,1fr);gap:20px;align-items:start}
.panel{background:#fff;border:1px solid #cfddd2;border-radius:16px;padding:22px;min-width:0}.panel+.panel{margin-top:16px}
.top{display:flex;justify-content:space-between;align-items:center;gap:12px;margin-bottom:14px}.scroll{overflow:auto}
table{width:100%;border-collapse:collapse;text-align:left;font-size:.9rem}th,td{padding:11px 8px;border-bottom:1px solid #e3ebe4}th{color:#415b4d;white-space:nowrap}td:first-child{min-width:130px;overflow-wrap:anywhere}
a{color:#206348}a:hover{text-decoration-thickness:2px}.button,button{display:inline-block;padding:8px 14px;border-radius:8px;background:#216249;color:white;border:0;text-decoration:none;cursor:pointer;font:inherit;white-space:nowrap}
.muted,small{color:#52665b}label{display:block;margin-top:12px;font-weight:650;font-size:.9rem}input:not([type=checkbox]),textarea,select{width:100%;padding:8px 10px;border:1px solid #9fb3a5;border-radius:8px;font:inherit;color:inherit;background:#fafdf9;margin-top:4px}textarea{min-height:62px;resize:vertical}input[type=checkbox]{accent-color:#216249}code{overflow-wrap:anywhere}.actions{margin-top:14px;display:flex;gap:12px;align-items:center}
.notice{background:#fff4d2;border:1px solid #e4cc82;padding:10px 14px;border-radius:8px;margin-bottom:15px}.copy{white-space:pre-wrap;overflow-wrap:anywhere;max-width:760px;margin:auto}.status{white-space:nowrap}
@media(max-width:850px){.layout{grid-template-columns:1fr}.panel{padding:16px}}
</style><body><header><h1>${escape(title)}</h1></header><main>${plain ? `<div class="panel copy">${escape(body)}</div>` : body}</main></body></html>`;
}

export function renderDashboard({ campaigns, counts, sources, current, draft, csrf, message }) {
  const values = draft || current || { mode: 'redirect', weight: 50, enabled: 1 };
  const tally = new Map(counts.map(row => [`${row.slug}:${row.variant}`, row.visits]));
  const rows = campaigns.map(row => `<tr>
    <td><a href="/admin?edit=${escape(row.slug)}">${escape(row.title)}</a><br><small>${escape(row.slug)}</small></td>
    <td class="status">${row.enabled ? '啟用' : '暫停'}</td>
    <td>${number(tally.get(`${row.slug}:A`))}</td><td>${number(tally.get(`${row.slug}:B`))}</td>
    <td>${row.enabled ? `<a href="/r/${escape(row.slug)}" target="_blank" rel="noopener">開啟</a>` : '—'}</td></tr>`).join('');
  const attribution = current ? `<section class="panel"><h2>${escape(current.title)}的流量來源</h2>
    <table><thead><tr><th>UTM 來源</th><th>瀏覽次數</th></tr></thead><tbody>
    ${sources.map(row => `<tr><td>${escape(row.source)}</td><td>${number(row.visits)}</td></tr>`).join('') || '<tr><td colspan="2">尚無紀錄。</td></tr>'}</tbody></table></section>` : '';
  return renderPage('活動分流後台', `${message ? `<p class="notice" role="alert">${escape(message)}</p>` : ''}
  <div class="layout"><div><section class="panel"><div class="top"><h2>活動成效</h2><a class="button" href="/admin">新增活動</a></div>
  <div class="scroll"><table><thead><tr><th>活動</th><th>狀態</th><th>A 次數</th><th>B 次數</th><th>連結</th></tr></thead>
  <tbody>${rows || '<tr><td colspan="5">新增第一個活動後即可開始分流。</td></tr>'}</tbody></table></div></section>${attribution}</div>
  <section class="panel"><h2>${current ? '編輯活動' : '新增活動'}</h2>
  ${current ? `<p class="muted">活動網址 <code>/r/${escape(current.slug)}</code></p>` : ''}
  <form method="post" action="${current ? `/admin?edit=${escape(current.slug)}` : '/admin'}">
  <input type="hidden" name="csrf" value="${escape(csrf)}"><input type="hidden" name="original" value="${escape(current?.slug)}">
  <label>活動名稱<input name="title" maxlength="100" required value="${escape(values.title)}"></label>
  <label>網址代號<input name="slug" maxlength="48" pattern="[a-z0-9][a-z0-9\\-]*" required value="${escape(current?.slug || values.slug)}" ${current ? 'readonly' : ''} placeholder="summer-sale"></label>
  <label>分流方式<select name="mode"><option value="redirect" ${values.mode === 'redirect' ? 'selected' : ''}>跳轉至外部網址</option><option value="inline" ${values.mode === 'inline' ? 'selected' : ''}>同網址顯示內容</option></select></label>
  <small>跳轉模式請填完整網址。同網址模式請填純文字。</small>
  <label>A 版本<textarea name="a" maxlength="2000" required>${escape(values.a)}</textarea></label>
  <label>B 版本<textarea name="b" maxlength="2000" required>${escape(values.b)}</textarea></label>
  <label>A 流量比例（%）<input type="number" name="weight" min="0" max="100" required value="${escape(values.weight)}"></label>
  <label><input type="checkbox" name="enabled" ${values.enabled ? 'checked' : ''}> 啟用活動</label>
  <div class="actions"><button type="submit">${current ? '儲存變更' : '建立活動'}</button></div></form></section></div>`);
}
